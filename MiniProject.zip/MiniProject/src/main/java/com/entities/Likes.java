package com.entities;

import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Likes {

	@Id
	int likeId;
	
	@ManyToOne
	private RegisterDetails username;
	
	@ManyToOne
	private Posts post;
	
	
	

	public int getLikeId() {
		return likeId;
	}

	public void setLikeId() {
		this.likeId = new Random().nextInt(100);
	}

	public RegisterDetails getUsername() {
		return username;
	}

	public void setUsername(RegisterDetails username) {
		this.username = username;
	}

	public Posts getPost() {
		return post;
	}

	public void setPost(Posts post) {
		this.post = post;
	}
	

	@Override
	public String toString() {
		return "Likes [username=" + username + ", post=" + post + "]";
	}
	
	
	
	
	
	
}
