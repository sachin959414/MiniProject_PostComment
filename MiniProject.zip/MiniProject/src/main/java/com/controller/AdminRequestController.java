package com.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.dao.Dao;
import com.entities.Posts;
import com.entities.RegisterDetails;
import com.services.PasswordEncBcy;

@Controller
@EnableWebMvc
public class AdminRequestController {
	
	@Autowired
	Dao dao;
	
	@Autowired
	PasswordEncBcy passenc ;
	
	@RequestMapping(value = "/adminregisterpage",method = RequestMethod.GET)
	public String adminregisterpage(HttpServletRequest req)
	{
		if(String.valueOf(req.getSession().getAttribute("usertype")).equals("ADMIN"))
		{
		return"adminregisterpage";
		}
		
		return "adminloginpage";
		
	}
	
	@RequestMapping(value = "/adminloginpage",method = RequestMethod.GET)
	public String adminloginpage()
	{
		
		return"adminloginpage";
	}
	
	@RequestMapping(value = "/adminaccounthome")
	public String adminAccountPage(HttpServletRequest req,ModelMap m)
	{
		if(String.valueOf(req.getSession().getAttribute("usertype")).equals("ADMIN"))
		{
			m.addAttribute("module", "blank");
			return "adminacountpage";
		}
		
		return"adminloginpage";
	}
	
	@RequestMapping(value = "/userdetails")
	public String showUserDetails(HttpServletRequest req,HttpServletResponse res,ModelMap m)
	{
	

		if(String.valueOf(req.getSession().getAttribute("usertype")).equals("ADMIN"))
		{
			ArrayList<RegisterDetails> users=dao.allusers();
			m.addAttribute("module","userdetail");
			m.addAttribute("users",users);
			System.out.println(users);
			return "adminacountpage";
		}
		
		
		return"adminloginpage";
	}
	
	@RequestMapping(value = "/postdetails")
	public String showPostDetails(HttpServletRequest req,HttpServletResponse res,ModelMap m)
	{
		if(String.valueOf(req.getSession().getAttribute("usertype")).equals("ADMIN"))
		{
			ArrayList<Posts> posts=dao.findAllPosts();
			

			
			
			for(Posts post :posts)
			{
				post.setLikes(dao.postLikes(post.getPostId()));
			}
			
			m.addAttribute("module","postdetail");
			m.addAttribute("posts", posts);
			
			System.out.println(posts);
			return "adminacountpage";
		}
		return"adminloginpage";
		
	}
	
	@RequestMapping(value = "/deleteuser/{username}")
	public String deletePost(@PathVariable("username") String username, HttpServletRequest req)
	{
		System.out.println(username);
		RegisterDetails user=dao.find(username);
		
		
		dao.deleteUser(user);
		
		return "redirect:/userdetails";
	}

	
	
	@RequestMapping(value = "/adminlogin", method = RequestMethod.POST)
	public String adminLogin(HttpServletRequest req, HttpServletResponse res, ModelMap m) {
		String username = (String) req.getParameter("username");
		String password = (String) req.getParameter("password");
		String usertype = "ADMIN";

		System.out.println(username+" "+password);
		
		ArrayList<RegisterDetails> user = dao.checkforloginUser(username, usertype);

		System.out.println(user);
		if (!user.isEmpty() && passenc.checkPass(password, user.get(0).getPassword()) == 1 ) {
			HttpSession session = req.getSession();
			session.setAttribute("username", user.get(0).getUserName());
			session.setAttribute("name", user.get(0).getName());
			session.setAttribute("usertype", user.get(0).getUsertype());

			return "redirect:adminaccounthome";

		}

		m.addAttribute("flag", "1");
		return"adminloginpage";

	}
	
	
	@RequestMapping(value = "/addadmin", method = RequestMethod.POST)
	public String userRegister(HttpServletRequest req, HttpServletResponse res, ModelMap m) {
		
		if(String.valueOf(req.getSession().getAttribute("usertype")).equals("ADMIN"))
		{
		
		String name = (String) req.getParameter("name");
		System.out.println(name);
		String email = (String) req.getParameter("email");
		String contact = (String) req.getParameter("contact");
		String username = (String) req.getParameter("username");

		System.out.println("check1 ");
		System.out.println(username);
		if (dao.userNameValidate(username) == 0) {
			System.out.println("check2");
			m.addAttribute("flag", "1");
			return "userregisterpage";

		}

		System.out.println("check3");
		String password = (String) req.getParameter("password");
		String userType = "ADMIN";
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("E, dd MMMM yyyy hh.mm aa");
		String strDate = formatter.format(date);

		RegisterDetails user = new RegisterDetails();

		user.setName(name);
		user.setEmail(email);
		user.setContact(contact);
		user.setUserName(username);
		user.setPassword(passenc.hashPassword(password));
		user.setUsertype(userType);
		user.setDate(strDate);

		dao.save(user);
		
		return "redirect:adminaccounthome";

		}
		
		return"adminloginpage";
	}

	

	

}
