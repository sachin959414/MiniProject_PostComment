package com.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.dao.Dao;
import com.entities.Comments;
import com.entities.Likes;
import com.entities.Posts;
import com.entities.RegisterDetails;
import com.services.PasswordEncBcy;

import jdk.vm.ci.code.Register;

@Controller
@EnableWebMvc
public class UserRequestController {

	@Autowired
	Dao dao;

	@Autowired
	PasswordEncBcy passenc;

	/* get request */

	@RequestMapping("/about")
	public String show() {

		return "aboutus";
	}

	@RequestMapping(value = "/userregisterpage", method = RequestMethod.GET)
	public String userRegisterPage() {

		return "userregisterpage";
	}

	@RequestMapping(value = "/userloginpage", method = RequestMethod.GET)
	public String userloginPage() {

		return "userloginpage";
	}

	@RequestMapping(value = "/logout")
	public String logout(HttpServletRequest req) {

		req.getSession().invalidate();

		return "redirect:/";
	}

	@RequestMapping(value = "/useraccount")
	public String userAccount(ModelMap m, HttpServletRequest req) {

		ArrayList<Posts> posts = dao.findAllPosts();
		for(Posts post :posts)
		{
			post.setLikes(dao.postLikes(post.getPostId()));
		}
		
		m.addAttribute("posts", posts);
		System.out.println(posts);
		return "useraccountpage";
	}

	@RequestMapping(value = "/comments/{postid}")
	public String CommentsPage(@PathVariable("postid") String postid, ModelMap m) {
		Posts post = dao.findPost(Integer.parseInt(postid));
		m.addAttribute("post", post);

		ArrayList<Comments> comments = dao.postComments(Integer.parseInt(postid));

		if (comments.isEmpty()) {
			m.addAttribute("flag", 1);

			return "commentspage";
		}

		m.addAttribute("comments", comments);

		System.out.println(comments);
		
		return "commentspage";
	}
	
	@RequestMapping(value = "/deletepost/{postid}")
	public String deletePost(@PathVariable("postid") String postid, HttpServletRequest req)
	{
		System.out.println(postid);
		Posts post=dao.findPost(Integer.parseInt(postid));
		
		System.out.println(post.getComments());
		
		dao.deletePost(post);
		
		return "redirect:/useraccount";
	}
	
	@RequestMapping(value = "/postlike/{postid}")
	public String postLike(@PathVariable("postid") String postid,HttpServletRequest req,HttpServletResponse res)
	{
		   String username=String.valueOf(req.getSession().getAttribute("username"));
		
		   RegisterDetails user=dao.find(username);
		   Posts post=dao.findPost(Integer.parseInt(postid));
		   Likes like =new Likes();
		   like.setLikeId();
		   like.setUsername(user);
		   like.setPost(post);
		   dao.saveLike(like);
		return "redirect:/useraccount";
	}

	/*----------------------------------------------------------------------------------------------------------- */

	/* Post Request */

	@RequestMapping(value = "/userregister", method = RequestMethod.POST)
	public String userRegister(HttpServletRequest req, HttpServletResponse res, ModelMap m) {
		String name = (String) req.getParameter("name");
		System.out.println(name);
		String email = (String) req.getParameter("email");
		String contact = (String) req.getParameter("contact");
		String username = (String) req.getParameter("username");

		System.out.println("check1 ");
		System.out.println(username);
		if (dao.userNameValidate(username) == 0) {
			System.out.println("check2");
			m.addAttribute("flag", "1");
			return "userregisterpage";

		}

		System.out.println("check3");
		String password = (String) req.getParameter("password");
		String userType = "USER";
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("E, dd MMMM yyyy hh.mm aa");
		String strDate = formatter.format(date);

		RegisterDetails user = new RegisterDetails();

		user.setName(name);
		user.setEmail(email);
		user.setContact(contact);
		user.setUserName(username);
		user.setPassword(passenc.hashPassword(password));
		user.setUsertype(userType);
		user.setDate(strDate);

		dao.save(user);

		return "userloginpage";
	}

	@RequestMapping(value = "/userlogin", method = RequestMethod.POST)
	public String userLogin(HttpServletRequest req, HttpServletResponse res, ModelMap m) {
		String username = (String) req.getParameter("username");
		String password = (String) req.getParameter("password");
		String usertype = "USER";

		ArrayList<RegisterDetails> user = dao.checkforloginUser(username, usertype);

		if (!user.isEmpty() && passenc.checkPass(password, user.get(0).getPassword()) == 1) {
			HttpSession session = req.getSession();
			session.setAttribute("username", user.get(0).getUserName());
			session.setAttribute("name", user.get(0).getName());
			session.setAttribute("usertype", user.get(0).getUsertype());

			return "redirect:/";

		}

		m.addAttribute("flag", "1");
		return "userloginpage";

	}

	@RequestMapping(value = "/addpost", method = RequestMethod.POST)
	public String addPost(HttpServletRequest req, HttpServletResponse res, ModelMap m) {
		String content = req.getParameter("posttext");

		RegisterDetails user = dao.find(String.valueOf(req.getSession().getAttribute("username")));

		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("E, dd MMMM yyyy hh.mm aa");
		String strDate = formatter.format(date);

		Posts post = new Posts();
		post.setContent(content);
		post.setDate(strDate);
		post.setPostId();
		post.setUsername(user);

		dao.savePost(post);

		return "redirect:/useraccount";
	}

	@RequestMapping(value = "/addcomment", method = RequestMethod.POST)
	public String addComment(ModelMap m, HttpServletRequest req) {
		Comments com = new Comments();
		RegisterDetails user = dao.find(String.valueOf(req.getSession().getAttribute("username")));
		String postid=req.getParameter("postid");
		Posts post = dao.findPost(Integer.parseInt(postid));

		String comment = req.getParameter("commenttext");

		com.setCommentcontent(comment);
		com.setCommentid();
		com.setPostid(post);
		com.setUser(user);
		dao.saveComment(com);

		
		return "redirect:/comments/"+postid+"";
	}

}
